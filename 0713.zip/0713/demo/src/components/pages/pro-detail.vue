<template>
    <div>
        <div class="container">
        <header class="header">
            <div class="wrap">
                <go-back></go-back>
                <h2>商品详情</h2>
                <div class="points">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </header>
        <div class="top">
            <img class="pic1" src="../../assets/images/detail_images/pic_1.jpg" alt="">
            <img class="pic2" src="../../assets/images/detail_images/pic_2.jpg" alt="">
        </div>
        <div class="name">
            <div class="wrap">
                <p class="p1">娅芝贵妇素颜霜 贵妇膏神仙膏补水保湿懒人霜遮瑕珍珠膏</p>
                <p class="p2">￥123.00 <span>（此价格不与套装优惠同时享受）</span></p>
            </div>
        </div>
        <div class="choose">
            <div class="box1">
                <div class="wrap">
                    <p>促销：<span>满减</span>满2件9折；3件8折</p>
                    <img src="../../assets/images/detail_images/arrow.jpg" alt="">
                </div>
            </div>
            <div class="box2">
                <div class="wrap">
                    <span>购买数量</span>
                    <ul class="clearfix">
                        <li><a href="#">-</a></li>
                        <li class="num">1</li>
                        <li class="up"><a href="#">+</a></li>
                    </ul>
                </div>
            </div>
            <div class="box3">
                <div class="wrap">
                    <div class="box3-1">
                        <span>商品属性</span>
                        <img src="../../assets/images/detail_images/arrow.jpg" alt="">
                    </div>
                    <div class="box3-2">
                    <span>规格</span>
                    <span class="red">30g</span>
                    <span class="brown">5g</span>
                </div>
                </div>
            </div>
        </div>
        <div class="detail">
            <p>商品详情</p>
            <img class="img3" src="../../assets/images/detail_images/pic_3.jpg" alt="">
            <img class="img4" src="../../assets/images/detail_images/pic_4.jpg" alt="">
            <img class="img5" src="../../assets/images/detail_images/pic_5.jpg" alt="">
            <img class="img6" src="../../assets/images/detail_images/pic_6.jpg" alt="">
            <img class="img7" src="../../assets/images/detail_images/pic_7.jpg" alt="">
        </div>
        <div class="discuss">
            <div class="wrap">
                <h2>商品评价</h2>
                <div class="one">
                    <p>123456</p>
                    <p>效果很好，物流很棒，下次继续来！</p>
                    <img class="img8" src="../../assets/images/detail_images/pic_8.jpg" alt="">
                    <img class="img9" src="../../assets/images/detail_images/pic_9.jpg" alt="">
                    <img class="img10" src="../../assets/images/detail_images/pic_10.jpg" alt="">
                    <span>2020-01-01</span>
                </div>
                <p class="clearfix">共100+条评论 <span>查看更多></span></p>
            </div>
        </div>
        <div class="footer">
            <div class="shopcar">
                <img src="../../assets/images/index_images/icon-shopcar_31.jpg" alt="">
                <p>购物车</p>
                <div>2</div>
            </div>
            <input type="botton" class="tocar" value="加入购物车">
            <input type="botton" class="buy" value="立即购买">
        </div>

    </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="" scopde>
    @import '../../assets/css/pro-detail.css'
</style>