<template>
  <div>
    <a href="#" @click='$router.go(-1)'>
      <img src="../assets/images/classify/arrow.jpg" alt />
      
    </a>
  </div>
</template>
<script>
export default {};
</script>
<style lang="" scoped>
img{
    width: 0.17rem;
    height: 0.29rem;
    margin-bottom: 0.3rem;
}
</style>