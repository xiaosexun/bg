import goBack from './goBack.vue'
export default{
    goBack
}