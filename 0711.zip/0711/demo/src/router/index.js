import Vue from 'vue'
import Router from 'vue-router'
//一级路由
import Index from '@/components/pages/index'
//二级路由
import Home from '@/components/views/home'
import Car from '@/components/views/car'
import Mine from '@/components/views/mine'
import Sure from '@/components/views/sure'
import ProList from '@/components/views/pro-list'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path:'/index',
      component:Index,
      children:[
        {
          path:'/home',
          component:Home
        },
        {
          path:'/car',
          component:Car
        },
        {
          path:'/mine',
          component:Mine
        },
        {
          path:'/sure',
          component:Sure
        },
        {
          path:'/pro-list',
          component:ProList
        },
        {//重定向
      path:'',
      redirect:'/home'
    }
      ]
    },
    {//重定向
      path:'*',
      redirect:'/index'
    }
  ]
})
